import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class TestDemoTest {

	private TestDemo testDemo;

	@BeforeEach
	void setUp() throws Exception {
		testDemo = new TestDemo();
	}

	@ParameterizedTest
	@MethodSource("TestDemoTest#argumentsForAddPositive")
	void assertThatTwoPositiveNumbersAreAddedCorrectly(int a, int b, int expected, Boolean expectException) {
		if (!expectException)
			Assertions.assertThat(testDemo.addPositive(a, b)).isEqualTo(expected);
		else
			Assertions.assertThatThrownBy(() -> testDemo.addPositive(a, b))
					.isInstanceOf(IllegalArgumentException.class);
	}

	/**
	 * Helper method to return stream of arguments to test addPositive(int a, int b)
	 * method
	 * 
	 * @return Stream<Arguments
	 */
	static Stream<Arguments> argumentsForAddPositive() {
		return Stream.of(Arguments.arguments(2, 4, 6, false), Arguments.arguments(-2, 4, -1, true),
				Arguments.arguments(2, 6, 8, false), Arguments.arguments(3, 3, 6, false),
				Arguments.arguments(7, 4, 11, false), Arguments.arguments(1, 1, 2, false),
				Arguments.arguments(-2, 4, -1, true), Arguments.arguments(-2, -4, -1, true),
				Arguments.arguments(0, 0, -1, true), Arguments.arguments(2, -4, -1, true));
	}

	/*
	 * Test method for correctiveness of randomNumberSquared(int a) method
	 */
	@Test
	void assertThatNumberSquaredIsCorrect() {
		TestDemo mockDemo = spy(testDemo);
		doReturn(5).when(mockDemo).getRandomInt();

		int fiveSquared = mockDemo.randomNumberSquared();
		Assertions.assertThat(fiveSquared).isEqualTo(25);
	}

}
