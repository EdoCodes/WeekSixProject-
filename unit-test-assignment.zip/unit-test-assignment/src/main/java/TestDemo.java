import java.util.Random;

public class TestDemo {

	/**
	 * 
	 * @param a
	 * @param b
	 * @return sum of a and b - if both are positive
	 * @throws IllegalArgumentException - if a or b is less than or equal to 0
	 */
	public int addPositive(int a, int b) {
		if (a <= 0)
			throw new IllegalArgumentException("Both parameters must be positive!");
		else if (b <= 0)
			throw new IllegalArgumentException("Both parameters must be positive!");
		return a + b;
	}

	/**
	 * 
	 * @return Square of a random number value
	 */
	public int randomNumberSquared() {
		int value = getRandomInt();
		return value * value;
	}

	/**
	 * 
	 * @return Random number within range 1 to 10 (both inclusive)
	 */
	int getRandomInt() {
		Random random = new Random();
		return random.nextInt(10) + 1;
	}
}
